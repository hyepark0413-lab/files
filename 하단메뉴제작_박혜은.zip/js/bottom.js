let lastScrollTop = 0;
const delta = 5;
const fixBox = document.querySelector('.bottomNav');
const fixBoxHeight = fixBox.offsetHeight;
let didScroll;

//스크롤 이벤트 
window.onscroll = function(e) {
    didScroll = true;
};

//0.25초마다 스크롤 여부 체크하여 스크롤 중이면 hasScrolled() 호출
setInterval(function(){
    if(didScroll){
        hasScrolled();
        didScroll = false;
    }
}, 250);

function hasScrolled(){
const nowScrollTop = window.scrollY;
if(Math.abs(lastScrollTop - nowScrollTop) <= delta){
        return;
}
if(nowScrollTop > lastScrollTop && nowScrollTop > fixBoxHeight){
        //Scroll down
        fixBox.classList.remove('show');
  }else{
   if(nowScrollTop+window.innerHeight<document.body.offsetHeight){
            //Scroll up    페이지 맨 아래가 아닐 때만
            fixBox.classList.add('show');
        }
    }
       lastScrollTop = nowScrollTop;
}
/*
nowScrollTop → 현재 스크롤 위치
window.innerHeight → 현재 브라우저 창 높이
document.body.offsetHeight → 문서 전체 높이

스크롤 위치 + 화면 높이 < 문서 전체 높이
==> 사용자가 페이지 맨 아래까지 도달하지 않았다면
    맨 아래에서는 show를 다시 추가하지 않도록 방지
*/










