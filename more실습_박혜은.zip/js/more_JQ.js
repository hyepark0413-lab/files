$(function(){
  let count = 0;
  let step;

  const items = $('#snack ul li');
  const total = items.length;

  items.hide();
  function setStep() {
    const w = $(window).width();
    if (w < 641) step = 2;        // 모바일 (2개)
   else if (w < 841) step = 3;   // 태블릿1 (3개)
   else if (w < 1200) step = 4;  // 태블릿2 (4개)
   else step = 5;                // PC (5개)
  }

  function init() {
    setStep();
    count = step;

    items.hide();
    items.slice(0, count).show(); 
    // slice(0,count) : 0번째에서 하나 전까지(배열) 추출해서 show: 보여라

     

    $('.btn').text('MORE');      // 초기 텍스트
    $('.btn').removeClass('less'); // 초기 색상 
  
  

  }
 // $('.btn').on('click',function (e) { 
 $(document).on('click', '.btn', function(e) {
   e.preventDefault();
  

  if(count < total){ // MORE 상태
        count = Math.min(count + step, total);
        items.slice(0, count).fadeIn();
 
    if(count >= total){
          $(this).text('LESS');       // 텍스트 변경
          $(this).addClass('less');   // 색상 변경
      
    }
  } else { // LESS 상태
      count = step;
      items.hide();
      items.slice(0,count).fadeIn();

      $(this).text('MORE');          // 텍스트 원래대로
      $(this).removeClass('less');   // 색상 원래대로
  }
      
  });
    


/*
// 마지막이면 버튼 숨김
    if (count >= total) {
      $('.more').fadeOut();
    }
*/
   


 $(window).on('resize', function () {
    init();
    $('.more').show(); 
  });

  init();
});


























