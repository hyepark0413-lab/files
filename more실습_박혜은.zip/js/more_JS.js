document.addEventListener("DOMContentLoaded", function() {
  let count = 0; //현재까지 보여준 개수
  let step; //한 번 클릭할 때 몇 개씩 추가할지

  const items = document.querySelectorAll("#snack ul li");
  const total = items.length; //전체 아이템 개수(13개) 저장

  const btn = document.querySelector(".btn"); //더보기 버튼 가져옴
  const moreWrap = document.querySelector(".more"); //버튼 감싸는 영역(숨길 때 사용)

  items.forEach(item => {
    item.style.display = "none"; //처음에 모든 아이템 숨김
  });


function setStep() { //화면 크기에 따라 보여줄 개수
  const w = window.innerWidth; //현재 브라우저 너비 가져옴 (제이쿼리에서는 전부 width();로 씀)

   if (w < 641) step = 2;        // 모바일 (2개)
   else if (w < 841) step = 3;   // 태블릿1 (3개)
   else if (w < 1200) step = 4;  // 태블릿2 (4개)
   else step = 5;                // PC (5개)
}

function showItems() { //아이템 보여주는 함수
  items.forEach((item, index) => {
    if(index < count) { //count 개수만큼만 보여줌
      item.style.display = "block"; //해당 아이템 보이게 처리
    }
  });
}

function init() { //화면세팅 초기화
  setStep();
  count = step; //처음엔 step만큼 보여줌

  items.forEach(item => {
    item.style.display = "none"; //다시 전체 숨김 초기화
  });
  showItems(); //step개수만큼 다시 보여줌
}

if(btn) {//버튼이 존재하면 
  btn.addEventListener("click",function(e) { //버튼 클릭 이벤트
    e.preventDefault();
    count=Math.min(count +step, total); //현재개수 + step만큼 추가해서 보여주되 total을 넘지않게 제한(Math.min)
    showItems(); //추가된 개수만큼 다시 보여줌

    //마지막이면 버튼 숨김(전부 다 보여줬으면)
    if(count >=total && moreWrap) { 
      moreWrap.style.display="none"; //버튼 숨김
    }
  });

}
//화면 크기 바뀔 때(반응형 대응)
window.addEventListener("resize", function() {
  init(); //페이지 처음 로딩 시 실행
  if(moreWrap) {
    moreWrap.style.display = "block";
  }
});

init();


});
























