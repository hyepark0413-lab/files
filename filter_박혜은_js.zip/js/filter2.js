document.addEventListener("DOMContentLoaded", function() {
    const tagged = {};

    document.querySelectorAll("#gallery img").forEach(function(img) {
       const tags = img.dataset.tags; //data-tags
        if(tags) {
            tags.split(",").forEach(function(tagName) {
                if(tagged[tagName] == null) { //아무것도 없으면 빈 배열,
                    tagged[tagName] = []; //있으면 push로 밀어넣어라
                } 
                  tagged[tagName].push(img);  
            });
         }
     });
//all버튼 (.first a)
document.querySelectorAll(".first a").forEach(function(btn) {
    btn.addEventListener("click", function(e) {
        e.preventDefault();
        
        document.querySelectorAll("#button li").forEach(li => {
            li.classList.remove("active");
        });
        this.classList.add("active");
        document.querySelectorAll("#gallery img").forEach(img => {
            img.style.display = "";
        });
    });
});
//태그 버튼 클릭 (#button li)
document.querySelectorAll("#button li").forEach(function(li) {
    li.addEventListener("click", function() {
        //"전체" active제거
        document.querySelectorAll(".first a").forEach(a => {
            a.classList.remove("active");
        });
        const tagName = this.textContent.trim();

        //active 처리
        this.classList.add("active");
        this.parentElement.querySelectorAll("li").forEach(sibling => {
           if(sibling !== this) sibling.classList.remove("active");
        });
        //전체 숨기기
        document.querySelectorAll("#gallery img").forEach(img => {
            img.style.display = "none";
        });

        //해당 태그만 보이기
        if(tagged[tagName]) {
            tagged[tagName].forEach(img => {
                img.style.display = "";
            });
        }

    });
});


});







$(function() {
    const tagged = {};
    $("#gallery img").each(function() {
        const img = this;
        const tags = $(this).data("tags");

        if(tags) {
            tags.split(",").forEach(function(tagName) {
                if(tagged[tagName] == null) { //아무것도 없으면 빈 배열,
                    tagged[tagName] = []; //있으면 push로 밀어넣어라
                } 
                  tagged[tagName].push(img);  
            });
        }
    });

    //all버튼
    $(".first a").on("click", function() {
        $("#button li").removeClass("active"); //글씨 빨간색 막기위해 클래스 제거
        $(this).addClass("active") //선택한 요소에 클래스 추가
        $("#gallery img").show(); //다 보여라
         return false; //a속성 막음
    });

    $.each(tagged, function(tagName) {
        $("#button li").on("click", function() {
            $(".fisrt a").removeClass("active");
            const aa=$(this).text(); //text() 모든 문자 가져옴
            $(this)
              .addClass("active")
              .siblings()
              .removeClass("active");
              $("#gallery img").hide().filter(tagged[aa]).show();
        });

    });

});





















