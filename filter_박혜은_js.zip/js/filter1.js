document.addEventListener("DOMContentLoaded", function() {
    const cache = [];

    document.querySelectorAll("#gallery img").forEach(function(img) {
        cache.push({
            element: img, //img요소를 찾아서
            text: img.alt.trim().toLowerCase() //alt 공백 없애고 소문자로 바꿔서 cache에 밀어넣음
        });
    });
    function filter() {
        const query = this.value.trim().toLowerCase(); //(value)입력한 값의 공백 없애고 소문자로
        cache.forEach(function(img) {
        let index = 0;
            if(query) {  //query값이 있으면(true)
                index = img.text.indexOf(query); //인덱스 번호를 못 찾으면 -1을 반환
            }
            img.element.style.display = index == -1 ? "none" : "" ;
            //-1과 같으면 보여주지말고, 그렇지않으면 공백(다 보여줘라)
    });
  }
  document
    .getElementById("filter-search")
    .addEventListener("keyup", filter);
});






























