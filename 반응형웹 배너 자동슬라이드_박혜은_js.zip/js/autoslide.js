document.addEventListener("DOMContentLoaded",initSlider);

//initSlider() 함수
function initSlider() {
  
//변수 선언 먼저
const mainImage = document.querySelector("#banner");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");
const bookRollImgs = document.querySelectorAll("#idc a");

let currentIndex = 0; //현재 인덱스 = 초기값 0
let autoSlideInterval;


//현재 보이는 ul 가져오기
//css에서 block, none처리를 했어도 다시 입력해줘야함 --> getComputedStyle(el) : 해당 요소에 적용된 최종 계산된 CSS값 전체를 가져옴
function getActiveUl() {
 const uls = mainImage.querySelectorAll("ul");
 for(let el of uls) {
    if(window.getComputedStyle(el).display !=="none") { //none이 아닌것=보이는 것
        return el;
    }
 }
}

//슬라이드 이동
function slideTo(index) {
const ul = getActiveUl();
const imgs = ul.querySelectorAll("li");
const totalSlides = imgs.length;

//인덱스가 0보다 작으면 안되기 때문에 0으로 보정. 전체 슬라이드 개수보다 넘어가면 -1
if(index < 0) index = 0;
if(index >= totalSlides) index = totalSlides -1;

const slideWidth = mainImage.clientWidth;
ul.style.transition = "transform 0.5s";
ul.style.transform = `translateX(-${slideWidth * index}px)`;
currentIndex = index; //여기서 인덱스 번호 바뀜

updateIndicators(); //인디케이터 동작 들어가는 함수, 인덱스 번호랑 매칭
}



//인디케이터
function updateIndicators() {
    bookRollImgs.forEach((el,i) => {
        el.classList.toggle("state_on", i ===currentIndex); 
    });
    /*  
    class를 toggle 시킴(왔다갔다)
    ->조건이 true면 클래스 추가, false면 제거
    (매칭되면 흰색 아니면 까만색active)
    jQuery의 toggleClass("클래스명", 조건)도 동일하게 동작
     */
}


//자동슬라이드
//setInterval : 자동으로 돌게 해주는 함수

function startAutoSlide() {
autoAutoSlideInterval = setInterval(() => {
    const ul = getActiveUl();
    const totalSlides = ul.querySelectorAll("li").length;
    let nextIndex = currentIndex + 1;
    if(nextIndex >=totalSlides) nextIndex = 0; //다시 처음 슬라이드로 돌아가게 index=0으로 보정

    slideTo(nextIndex); //이동시키는 함수에서 이동시키기 위해 호출

},3000); //(작업,시간)->setInterval- {}:작업, 3000: 시간

/*
=>화살표 함수( 소괄호가 앞으로 오고 function이라는 글자가 "=>" 가 됨) 
: function test() {} = test() =>
    */
}


//잠시 멈추는 함수. 화살표/인디케이터 클릭할 때 충돌 방지
function stopAutoSlide() {
    clearInterval(autoSlideInterval); //clearInterval 자동슬라이드 끝내는 함수
}




//이벤트. 화살표 클릭
function setEventListeners() {
    prevBtn.addEventListener("click",(e) => {
        e.preventDefault();
        stopAutoSlide(); //잠시 멈춤
        slideTo(currentIndex - 1); //클릭
        startAutoSlide(); //다시 돌리기 시작
    });

    nextBtn.addEventListener("click",(e) => {
        e.preventDefault();
        stopAutoSlide(); //잠시 멈춤
        slideTo(currentIndex + 1); //클릭
        startAutoSlide(); //다시 돌리기 시작
    });


//인디케이터 클릭
bookRollImgs.forEach((el, index) => {
el.addEventListener("click", (e) => {
    e.preventDefault();
    stopAutoSlide();
    slideTo(index); //인덱스랑 인디케이터랑 매칭. 인디케이터 클릭
    startAutoSlide();
   });
 });


//화면 리사이즈 될 때마다 인덱스 잡아줌
window.addEventListener("resize", ()=> {
    slideTo(currentIndex);
});

}



//초기실행 ---> 전체 실행됨, 먼저 써놓고 시작하면 작동 확인할 수 있음
slideTo(0);
startAutoSlide();
setEventListeners();
}





























