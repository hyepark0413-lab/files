$(document).ready(function(){
  initSlider();
});

function initSlider() {
  const $mainImage = $("#banner");
  const $prevBtn = $(".prev");
  const $nextBtn = $(".next");
  const $bookRollImgs = $("#idc a");

   let currentIndex = 0;
   let autoSlideInterval;

 // 현재 보이는 ul 가져오기
    function getActiveUl() {
       const $uls = $mainImage.find("ul"); 
       let $activeUl;

 $uls.each(function () {
      if ($(this).css("display") !== "none") {
        $activeUl = $(this);
        return false; // break
      }
    });
       return $activeUl;
    }

 // 슬라이드 이동
function slideTo(index) {
    const $ul = getActiveUl();
    const $imgs = $ul.find("li");
    const totalSlides = $imgs.length;
if (index < 0) index = 0;
if (index >= totalSlides) index = totalSlides - 1;
  const slideWidth = $mainImage.width();

  $ul.css({
      transition: "transform 0.5s",
      transform: `translateX(-${slideWidth * index}px)`
    });
    currentIndex = index;
    updateIndicators();
}
 // 인디케이터 업데이트
  function updateIndicators() {
    $bookRollImgs.each(function (i) {
      $(this).toggleClass("state_on", i === currentIndex);
    });
  }

  //자동슬라이드
function startAutoSlide() {
autoSlideInterval = setInterval(function(){
    const $ul = getActiveUl();
    const totalSlides = $ul.find("li").length;
    let nextIndex = currentIndex + 1;
    if (nextIndex >= totalSlides) nextIndex = 0;

    slideTo(nextIndex);
  },3000);
}

 function stopAutoSlide() {
    clearInterval(autoSlideInterval);
  }

//이벤트 등록  
  function setEventListeners(){
     $prevBtn.on("click", function(e){
        e.preventDefault();
        stopAutoSlide();
        slideTo(currentIndex - 1);
        startAutoSlide();
     });
    
     $nextBtn.on("click", function(e){
      e.preventDefault();
      stopAutoSlide();
      slideTo(currentIndex + 1);
      startAutoSlide();
     });  

 $bookRollImgs.each(function (index) {
   $(this).on("click", function(e){
     e.preventDefault();
     stopAutoSlide();
     slideTo(index);
     startAutoSlide();
   });
 });

$(window).on("resize", function () {
      slideTo(currentIndex);
    });
  }

  //초기실행
  slideTo(0);
  startAutoSlide();
  setEventListeners();
}





