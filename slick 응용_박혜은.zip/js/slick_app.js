$(function(){
    $('.slider').slick({
        autoplay: true,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,  // 화면 단위로 이동
        dots: true,       
        //인디케이터 개수 묶기
        customPaging: function(slider, i) { //dot만들 때마다 실행되는 함수,i-> dot번호
            const totalSlides = slider.slideCount; //전체 슬라이드 개수
          
            //전체 슬라이드를 보여지는 개수로 나누고 올림해서 필요한 dot개수 만들기
            const visibleDots = Math.ceil(totalSlides / 4); 
            if(i < visibleDots){ //필요한 개수보다 작으면

               //버튼 만들어서 반환해라 번호는 i + 1
                return '<button class="dot">' + (i + 1) + '</button>';
            } else {
                return ''; //아니면 아무것도 안만듦
            }
        },
        responsive: [   
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3   // 화면 단위
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]     
    });

    $(".slick-buttons a").on("click", function(e){
        e.preventDefault(); 
        const n=$(this).index();
        $(".slider").slick("slickUnfilter"); // 필터 초기화

        if(n==1){
            $(".slider").slick("slickFilter", $(".slider li.ppp"));
        } 
        else if(n==2){
            $(".slider").slick("slickFilter", $(".slider li.ggg"));
        } 
        else if(n==3){
            $(".slider").slick("slickFilter", $(".slider li.add"));
        } 
        else if(n==4){
            $(".slider").slick("slickFilter", $(".slider li.aaa"));
        } 
        else if(n==5){
            $(".slider").slick("slickFilter", $(".slider li.uuu"));
        }
        
        // 필터 적용 후 첫 슬라이드로 이동
        $(".slider").slick("slickGoTo", 0, true);
    });
});

























