<? 
// 세션을 시작함
// 로그인 정보($_SESSION['userid'], $_SESSION['username'])를 사용하기 위해 필요함
session_start(); 
?>
<meta charset="utf-8">
<?

   // 원래는 POST로 userid를 받을 수도 있지만, 현재 코드는 세션의 userid를 사용함
   // $userid=$_POST['userid'];

   // 로그인한 사용자의 아이디를 세션에서 가져옴
   $userid=$_SESSION['userid'];

   // 로그인한 사용자의 이름을 세션에서 가져옴
   $username=$_SESSION['username'];

   // 글쓰기/수정 폼에서 POST로 넘어온 제목을 받음
   $subject=$_POST['subject'];

   // 글쓰기/수정 폼에서 POST로 넘어온 내용을 받음
   $content=$_POST['content'];


   // 로그인하지 않은 상태라면 글 작성/수정을 막음
   if(!$_SESSION['userid'] ){
        echo("
        <script>
         window.alert('로그인 후 이용해 주세요.')
         history.go(-1)
       </script>
        ");
        exit;
   }

   // 제목이 비어 있으면 경고창을 띄우고 이전 페이지로 돌아감
   if(!$_POST['subject'] ){
        echo("
       <script>
         window.alert('제목을 입력하세요.')
         history.go(-1)
       </script>
        ");
     exit;
   }

   
   // 내용이 비어 있으면 경고창을 띄우고 이전 페이지로 돌아감
   if(!$_POST['content'] ){
        echo("
       <script>
         window.alert('내용을 입력하세요.')
         history.go(-1)
       </script>
        ");
     exit;
   }

   // 현재 날짜와 시간을 저장함
   // 예: 2026-05-06 (14:30)
   $regist_day = date("Y-m-d (H:i)");  // 현재의 '년-월-일-시-분'을 저장

   // DB 연결 파일을 불러옴
   include "dbconn.php";       

// 글 작성/수정 후 이동할 목록 페이지 번호를 1로 설정
$page = 1;    
   
// GET으로 넘어온 modify 값을 $mode에 저장
$mode=$_GET['modify'];

// GET으로 넘어온 글 번호를 $num에 저장
// 수정 모드일 때 어떤 글을 수정할지 구분하는 값
$num=$_GET['num'];

// 주소창에 mode 값이 있으면 그 값을 $mode에 다시 저장
if (isset($_GET["mode"]))
    $mode = $_GET["mode"];
  else
    // mode 값이 없으면 빈 문자열로 설정
    $mode = "";

// HTML 입력 허용 여부를 저장하는 변수
// 현재는 빈 값이므로 HTML 사용 안 함 상태
$html_ok = "";

// mode 값이 modify이면 기존 글 수정 처리
if ($mode=="modify")
    {
        // boardlist 테이블에서 num이 $num인 글의 제목과 내용을 수정함
        $sql = "update boardlist set subject='$subject', content='$content' where num=$num";
    }
    else
    {
        // 새 글 작성 처리

        // HTML 사용을 허용하는 경우
        if ($html_ok=="y")
        {
            // is_html 값을 y로 저장해서 HTML 글임을 표시
            $is_html = "y";
        }
        else
        {
            // HTML 사용을 허용하지 않는 경우
            $is_html = "";

            // 사용자가 입력한 HTML 태그를 문자로 바꿔서 실행되지 않게 함
            // 예: <br> → &lt;br&gt;
            $content = htmlspecialchars($content);
        }

        // 새 글을 boardlist 테이블에 추가하는 SQL문의 앞부분
        $sql = "insert into boardlist (id, name,  subject, content, regist_day, hit, is_html) ";

        // 새 글에 들어갈 실제 값들을 SQL문에 이어 붙임
        // hit은 새 글이므로 0부터 시작
        $sql .= "values('$userid', '$username',  '$subject', '$content', '$regist_day', 0, '$is_html')";
    }

/** @var mysqli $connect */
// $sql에 저장된 SQL 명령을 실행함
// modify 모드이면 update 실행, 아니면 insert 실행
mysqli_query( $connect,$sql);  // $sql 에 저장된 명령 실행

// DB 연결을 끊음
mysqli_close($connect);                // DB 연결 끊기

// 글 작성 또는 수정이 끝나면 목록 페이지로 이동
echo "
       <script>
        location.href = 'list.php?page=$page';
       </script>
    ";
?>

<!-- 
1. 세션 시작
2. 로그인 사용자 정보 가져오기
3. POST로 제목/내용 가져오기
4. 로그인 여부 검사
5. 제목 입력 여부 검사
6. 내용 입력 여부 검사
7. DB 연결
8. mode가 modify인지 확인
9. modify면 기존 글 update
10. modify가 아니면 새 글 insert
11. SQL 실행
12. DB 연결 종료
13. list.php로 이동

-->

<!--  
$page = 1 → 오류 방지 + 기본 페이지 지정
htmlspecialchars :
문자열에서 특정한 특수 문자를 HTML 엔티티로 변환해서 단순 텍스트로 표시되도록 만듬 
이함수를 사용하면 악성 사용자로 부터 XSS 공격을 방지 할 수 있음

[특수문자]   [변환한 문자]
&(앰퍼샌드)   &amp;
""(겹따옴표)   &quot;

''(홑따옴표)    &#039;

<(미만)   &lt;

>(이상)    &gt;

-->

  
