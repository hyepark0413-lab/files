﻿<? 
	session_start(); 
?>
<!doctype html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
<link rel="stylesheet" href="css/greet.css?v=20260605-simple4">
<style>
 p a {font-size:20px;margin-bottom:10px;}
 #wrap {width:1000px; margin-right: auto;
        margin-left: auto;min-height:600px;
        margin-top:200px;}
#header {margin-bottom:200px;}
a {text-decoration:none;color:gray;}
</style>
</head>

<body>
<?php
include "dbconn.php";


$mode = $_GET['search']; 
$page = $_GET['page']; 
$find = $_POST['find']; 
$search = $_POST['search']; 


if (isset($_GET["mode"]))
    $mode = $_GET["mode"];
else
    $mode = "";

$scale=10;


if($mode == "search")
{
   
   if(!$search)
        {
            echo("
                <script>
                 window.alert('검색어를 입력해 주세요.');
                 history.go(-1);
                </script>
            ");
            exit;
        }

 
 $sql = "select * from boardlist where $find 
       like '%$search%' order by num desc";   
}
else
{
  $sql = "select * from boardlist order by num desc";
}

$result = mysqli_query( $connect,$sql);

$total_record = mysqli_num_rows($result); 

if ($total_record % $scale == 0)     
        $total_page = floor($total_record/$scale);
else
        $total_page = floor($total_record/$scale) + 1;

if (!$page) 
    $page = 1;

    */

$start = ($page - 1) * $scale;     

$number = $total_record - $start;   
?>

<div id="wrap">
<p> <a href="main.html">HOME</a></p>
 <div id="col2">
  <div id="title">BOARD</div>
  <form name="board_form" method="post" action="list.php?mode=search">
    <div id="list_search">
     <div id="list_search1">총 <?= $total_record ?>개의 게시물이 있습니다</div>
     <div id="list_search2">
        <img src="image/select_search.gif">
     </div>
     <div id="list_search3">
       <select name="find">
         <option value='subject'>제목</option>
         <option value='content'>내용</option>
         <option value='id'>아이디</option>
         <option value='name'>이름</option>
       </select>
     </div>
     <div id="list_search4">
      <input type="text" name="search">
     </div>
     <div id="list_search5">
<input type="image" src="image/list_search_button.gif">    
     </div>
    </div> 
  </form>

<div id="list_top_title">
<ul>
<li id="list_title1">
    <img src="image/list_title1.gif">
</li>
<li id="list_title2">
    <img src="image/list_title2.gif">
</li>
<li id="list_title3">
    <img src="image/list_title3.gif">
</li>
<li id="list_title4">
    <img src="image/list_title4.gif">
</li>
<li id="list_title5">
    <img src="image/list_title5.gif">
</li>
</ul>
</div>

<div id="list_content">
<?php
for($i=$start; $i<$start+$scale && $i < $total_record; $i++)                    
   {
      mysqli_data_seek($result, $i);       

      $row = mysqli_fetch_array($result);       

      $item_num     = $row['num'];

      $item_id      = $row['id'];

      $item_name    = $row['name'];

      $item_hit     = $row['hit'];

      $item_date    = $row['regist_day'];

      $item_date = substr($item_date, 0, 10);  

 $item_subject = str_replace(" ", "&nbsp;", $row['subject']);

?>
<div id="list_item">
        <div id="list_item1"><?= $number ?></div>
        <div id="list_item2">
<a href="view.php?num=<?=$item_num?>&page=<?=$page?>">
  <?= $item_subject ?></a></div>
        <div id="list_item3"><?= $item_id ?></div>
        <div id="list_item4"><?= $item_date ?></div>
        <div id="list_item5"><?= $item_hit ?></div>
</div>
<?
       $number--;
   }
?>
   <div id="page_button">
<div id="page_num">이전 &nbsp;&nbsp;&nbsp;&nbsp; 
<?
   for ($i=1; $i<=$total_page; $i++)
   {
        if ($page == $i)
        {
            echo "<b> $i </b>";
        }
        else
        { 
            echo "<a href='list.php?page=$i'> $i </a>";
        }      
   }
?>          
&nbsp;&nbsp;&nbsp;&nbsp;다음
</div>
<div id="button">
<a href="list.php?page=<?=$page?>">
  <img src="image/list.png"></a>&nbsp;
<? 
    if($_SESSION['userid'] )
    {
?>
        <a href="write_form.php">
      <img src="image/write.png"></a>
<?
    }
?>
    </div>
    </div>

</div>
 </div>
</div>
</body>

</html>    







