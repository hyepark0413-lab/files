﻿<?
    session_start();
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>회원정보 수정</title>
<link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
<link rel="stylesheet" href="css/base.css?v=20260605-simple4">
<script>
function check_input() {
  if (!document.member_form.pass.value) { alert("비밀번호를 입력하세요."); document.member_form.pass.focus(); return; }
  if (!document.member_form.pass_confirm.value) { alert("비밀번호 확인을 입력하세요."); document.member_form.pass_confirm.focus(); return; }
  if (document.member_form.pass.value !== document.member_form.pass_confirm.value) {
    alert("비밀번호가 일치하지 않습니다. 다시 입력해 주세요.");
    document.member_form.pass.focus();
    document.member_form.pass.select();
    return;
  }
  if (!document.member_form.name.value) { alert("이름을 입력하세요."); document.member_form.name.focus(); return; }
  if (!document.member_form.hp.value) { alert("전화번호를 입력하세요."); document.member_form.hp.focus(); return; }
  document.member_form.submit();
}
function reset_form() {
  document.member_form.pass.value = "";
  document.member_form.pass_confirm.value = "";
  document.member_form.name.value = "";
  document.member_form.hp.value = "";
  document.member_form.pass.focus();
}
</script>
</head>
<body>
<?php
 include "dbconn.php";
 /** @var mysqli $connect */
 mysqli_query($connect,'set names utf8');
 $sql = "select * from mb1 where id='$_SESSION[userid]'";
 $result = mysqli_query($connect,$sql);
 $row = mysqli_fetch_array($result);
 mysqli_close($connect);
?>
<div id="header">
  <? include "top_login2.php"; ?>
</div>
<div id="join_mem">
<h2>회원정보 수정</h2>
<form name="member_form" method="post" action="modify.php">
  <input type="hidden" name="id" value="<?=$row['id']?>">
  <div id="form_join">
    <div id="join1">
      <ul>
        <li><label for="a1">아이디</label><?= $row['id'] ?></li>
        <li><label for="a2">비밀번호</label><input type="password" name="pass" id="a2" value="<?= $row['pass'] ?>"></li>
        <li><label for="a3">비밀번호 확인</label><input type="password" name="pass_confirm" id="a3" value="<?= $row['pass'] ?>"></li>
        <li><label for="a4">이름</label><input type="text" name="name" id="a4" value="<?= $row['name'] ?>"></li>
        <li><label for="a5">전화번호</label><input type="text" name="hp" id="a5" value="<?= $row['hp'] ?>"></li>
      </ul>
    </div>
  </div>
  <div id="button">
    <button type="button" class="btn-submit-post" onclick="check_input()">저장</button>
    <button type="button" class="btn-small" onclick="reset_form()">초기화</button>
  </div>
</form>
</div>
</body>
</html>

