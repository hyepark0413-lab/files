﻿<? 
	session_start(); 
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>html5</title>
<link rel="stylesheet" href="css/reset.css?v=20260605-simple2">
<link rel="stylesheet" href="css/base.css?v=20260605-simple2">
<style>
#join_mem {width:400px;transform:translate(-50%,-50%);
position:absolute;left:50%;top:50%;padding:20px;
border:1px solid gray;}	   
#write_button {text-align:center;}	
#join2 ul label {display:inline-block;width:120px;}
#join2 ul li {margin-bottom:10px;height:25px;}
#join2 ul li input {height:25px;
                    border:1px solid gray;} 
</style>
</head>
<body>
<div id="join_mem">
<form  name="member_form" method="post" 
  action="id_search.php"> 
<div id="join2">
<ul>
    <li>
        <label for="a1">이름 </label>
<input type="text" name="name" width="140px"
 placeholder="이름" id="a1">        
    </li>
    <li>
       <label for="a2" class="b2">HP</label> 
     <input type="text" class="hp" name="hp" id="a2">   
    </li>
</ul>
</div>
<div id="write_button">
    <input type="image" src="image/ok.png">
</div>
</form>  
</div>
</body>
</html>






