<?php
// 세션을 사용하기 위해 시작함
// 로그인 여부는 보통 $_SESSION 안의 값으로 확인함
session_start();

// 주소창(GET)으로 넘어온 삭제할 글 번호를 받음
// 예: delete.php?num=3 이면 $num에는 3이 들어감
$num=$_GET['num'];

// DB 연결 파일을 불러옴
include "dbconn.php";

// $_SESSION['userid']가 없으면 로그인하지 않은 상태로 판단함
if (!isset($_SESSION['userid'])) {

      // 로그인하지 않은 사용자가 삭제하려고 하면 경고창을 띄움
      echo("
        <script>
         window.alert('로그인 후 삭제가능.')
         history.go(-1);
       </script>
        ");

     // 아래 코드가 실행되지 않도록 여기서 종료
     exit;

  }else{

   // 로그인한 상태라면 삭제 SQL문을 만듦
   // boardlist 테이블에서 num 값이 $num인 글을 삭제함
   $sql = "delete from boardlist where num = $num";
}

/** @var mysqli $connect */
// 위에서 만든 SQL문을 실행함
// 로그인하지 않은 경우에는 exit 때문에 여기까지 오지 않음
mysqli_query( $connect,$sql);

// DB 연결을 닫음
mysqli_close($connect);

// 삭제가 끝난 뒤 list.php 게시판 목록 페이지로 이동함
echo "
       <script>
        location.href = 'list.php';
       </script>
    ";
?>


<!-- 
1. 세션 시작
2. 삭제할 글 번호 num 받기
3. DB 연결
4. 로그인 여부 확인
5. 로그인 안 됨 → 경고창 → 이전 페이지 → 종료
6. 로그인 됨 → delete SQL 만들기
7. SQL 실행해서 글 삭제
8. DB 연결 닫기
9. list.php로 이동

-->