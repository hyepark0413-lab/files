﻿<?php
  session_start(); 

  include "dbconn.php";

  $num=$_GET['num']; // 二쇱냼李?GET)?쇰줈 ?섏뼱??湲 踰덊샇瑜?諛쏆쓬
  $page=$_GET['page']; // 二쇱냼李?GET)?쇰줈 ?섏뼱???꾩옱 ?섏씠吏 踰덊샇瑜?諛쏆쓬

 /** @var mysqli $connect */

 // boardlist ?뚯씠釉붿뿉??湲 踰덊샇媛 $num??寃뚯떆湲 ?섎굹瑜?媛?몄삤??SQL臾?
$sql = "select * from boardlist where num=$num"; 

// SQL臾??ㅽ뻾
$result = mysqli_query( $connect,$sql);

// ?ㅽ뻾 寃곌낵?먯꽌 寃뚯떆湲 ??以꾩쓣 諛곗뿴濡?媛?몄샂
$row = mysqli_fetch_array($result);  
$item_num     = $row['num']; // 寃뚯떆湲 踰덊샇
$item_id      = $row['id']; // ?묒꽦???꾩씠??
$item_name    = $row['name']; // ?묒꽦???대쫫
$item_hit     = $row['hit']; // 조회??
$item_date    = $row['regist_day']; // ?묒꽦 ?좎쭨
$item_subject = str_replace(" ", "&nbsp;", $row['subject']); // ?쒕ぉ??怨듬갚??&nbsp;濡?諛붽퓭??HTML?먯꽌 怨듬갚???좎??섍쾶 ??
$item_content = $row['content']; // 寃뚯떆湲 ?댁슜
$is_html      = $row['is_html']; // HTML ?ъ슜 ?щ?

// HTML 湲???꾨땺 寃쎌슦?먮쭔 ?쇰컲 ?띿뒪???뺤떇?쇰줈 異쒕젰?섍쾶 蹂??
if ($is_html!="y")
{
    // ?댁슜??怨듬갚??&nbsp;濡?諛붽퓭??HTML?먯꽌 怨듬갚???좎??섍쾶 ??
    $item_content = 
    str_replace(" ", "&nbsp;", $item_content);

    // 以꾨컮轅?臾몄옄瑜?<br> ?쒓렇濡?諛붽퓭???붾㈃?먯꽌 以꾨컮轅덈릺寃???
    $item_content = 
    str_replace("\n", "<br>", $item_content);
}   

$new_hit = $item_hit + 1; // 湲곗〈 조회?섏뿉 1???뷀븿

// 조회?섎? 1 利앷??쒗궎??SQL臾?
$sql = "update boardlist set hit=$new_hit 
where num=$num";   // 湲 조회??利앷??쒗궡

// 조회??利앷? SQL臾??ㅽ뻾
mysqli_query( $connect,$sql);
?>

<!DOCTYPE html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
<link rel="stylesheet" href="css/greet.css?v=20260605-simple4">
<script>

</script>
<style>
        #wrap {
    width:1000px;
    margin-right: auto;
    margin-left: auto;
    min-height:600px;
    margin-top:200px;

} 
#content #col2 {
    width:830px;
    min-height:558px;
    float:left;
    margin-left:15px;
}
</style>
</head>
<body>
<div id="wrap">
  <div id="content"> 
    <div id="col2">
      <div id="title">
            <img src="image/title_greet.gif">
      </div>
      <div id="view_comment"> &nbsp;</div>
<div id="view_title">
  <div id="view_title1"><?= $item_subject ?></div>
   <div id="view_title2">
    <?= $item_id ?>| 조회 : <?= $item_hit ?> |
    <?= $item_date ?> 
   </div>
</div> <!-- end of view_title -->
       <div id="view_content">
         <!-- content ?댁슜遺遺?-->
          <?= $item_content ?>
       </div>
    <div id="view_button">
    <a href="list.php?page=<?=$page?>">
    <img src="image/list.png"></a>&nbsp;
<?php
$userid=$_SESSION['userid']; // ?몄뀡????λ맂 濡쒓렇???ъ슜???꾩씠?붾? $userid?????

// ?꾩옱 肄붾뱶?먯꽌??$item_id???몄뀡 ?꾩씠?붾? ?ㅼ떆 ?ｊ퀬 ?덉쓬
// 利? ?꾩뿉??DB?먯꽌 媛?몄삩 ?묒꽦???꾩씠?붽? ?ш린??濡쒓렇???꾩씠?붾줈 諛붾?
$item_id=$_SESSION['userid'];

// 濡쒓렇?명븳 ?꾩씠?붿? 湲 ?묒꽦???꾩씠?붽? 媛숈쑝硫??섏젙/??젣 踰꾪듉??蹂댁뿬二쇨린 ?꾪븳 議곌굔
if($userid==$item_id)
{
?>
<a href="modify_form.php?num=<?=$num?>&page=<?=$page?>">
    <img src="image/modify.png"></a>&nbsp;
<a href="delete.php?num=<?=$num?>&page=<?=$page?>">
   <img src="image/delete.png"></a>&nbsp;          
<?
    }
?>
<?php
// 濡쒓렇?명븳 ?ъ슜?먮씪硫?湲?곌린 踰꾪듉??蹂댁뿬以?
if($userid)
    {
?>
<a href="write_form.php">
    <img src="image/write.png"></a>
<?
    }
?>

</div>  <!-- end of view_button -->

    <div class="clear"></div>
    </div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->        
</body>
</html>








