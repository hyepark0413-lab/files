﻿<!doctype html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그인</title>
    <link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
    <link rel="stylesheet" href="css/base.css?v=20260605-simple4">
    <link rel="stylesheet" href="css/main.css?v=20260605-simple4">
</head>
<body class="login-page">
    <h1 class="login-home"><a href="main.html">Home</a></h1>
    <div id="login">
        <form name="member_form" method="post" action="login.php">
            <p>
                <label for="name">아이디</label>
                <input type="text" id="name" name="id" autocomplete="username">
            </p>
            <p>
                <label for="pwd">비밀번호</label>
                <input type="password" id="pwd" name="pass" autocomplete="current-password">
            </p>
            <p class="center">
                <input type="submit" value="로그인">
                <a href="member_form.php">회원가입</a>
                <a href="id_screen.php" class="mm">아이디 찾기</a>
                <a href="pw_screen.php" class="mm">비밀번호 찾기</a>
            </p>
        </form>
    </div>
</body>
</html>




