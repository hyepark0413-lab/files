<?php
$connect=mysqli_connect("localhost","hyxxun0413","christy2209^^","hyxxun0413") or
die("SQL server에 연결할 수 없습니다.");

mysqli_select_db ($connect,"hyxxun0413");
?>