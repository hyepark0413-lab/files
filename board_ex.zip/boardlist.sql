/*게시판에 글쓰기 했을 때 데이터*/
create table boardlist(
    num int not null auto_increment,
    id varchar(15) not null,
    name varchar(10) not null,
    subject varchar(100) not null,
    content text not null, /*text 긴 문자열(varchar로 잡아도 됨)*/
    regist_day varchar(20),
    hit int,
    is_html varchar(1),
    primary key (num)
)engine=innoDB charset=utf8;