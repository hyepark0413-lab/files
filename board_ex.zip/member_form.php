﻿<?
    session_start();
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>회원가입</title>
<link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
<link rel="stylesheet" href="css/base.css?v=20260605-simple4">
<script>
function check_id() {
  window.open("check_id.php?id=" + document.member_form.id.value, "IDcheck", "left=200,top=200,width=260,height=100,scrollbars=no,resizable=yes");
}
function check_input() {
  const re1 = /^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$/;
  const id = document.member_form.id.value;
  if (!id) { alert("아이디를 입력하세요."); document.member_form.id.focus(); return; }
  if (!re1.test(id)) { alert("아이디는 6~10자의 영문, 숫자, 특수기호를 조합해 주세요."); return; }
  if (!document.member_form.pass.value) { alert("비밀번호를 입력하세요."); document.member_form.pass.focus(); return; }
  if (!document.member_form.pass_confirm.value) { alert("비밀번호 확인을 입력하세요."); document.member_form.pass_confirm.focus(); return; }
  if (document.member_form.pass.value !== document.member_form.pass_confirm.value) {
    alert("비밀번호가 일치하지 않습니다. 다시 입력해 주세요.");
    document.member_form.pass.focus();
    document.member_form.pass.select();
    return;
  }
  if (!document.member_form.name.value) { alert("이름을 입력하세요."); document.member_form.name.focus(); return; }
  if (!document.member_form.hp.value) { alert("전화번호를 입력하세요."); document.member_form.hp.focus(); return; }
  document.member_form.submit();
}
function reset_form() {
  document.member_form.id.value = "";
  document.member_form.pass.value = "";
  document.member_form.pass_confirm.value = "";
  document.member_form.name.value = "";
  document.member_form.hp.value = "";
  document.member_form.id.focus();
}
</script>
</head>
<body>
<div id="join_mem">
<h2>회원가입</h2>
<form name="member_form" method="post" action="insert.php">
  <div id="form_join">
    <div id="join1">
      <ul>
        <li><label for="a1">아이디</label><input type="text" name="id" id="a1"> <button type="button" class="btn-small" onclick="check_id()">중복확인</button></li>
        <li><label for="a2">비밀번호</label><input type="password" name="pass" id="a2"></li>
        <li><label for="a3">비밀번호 확인</label><input type="password" name="pass_confirm" id="a3"></li>
        <li><label for="a4">이름</label><input type="text" name="name" id="a4"></li>
        <li><label for="a5">전화번호</label><input type="text" name="hp" id="a5"></li>
      </ul>
    </div>
  </div>
  <div id="button">
    <button type="button" class="btn-submit-post" onclick="check_input()">저장</button>
    <button type="button" class="btn-small" onclick="reset_form()">초기화</button>
  </div>
</form>
</div>
</body>
</html>

