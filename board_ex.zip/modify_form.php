﻿<? 
    // ?몄뀡???쒖옉??
    // 濡쒓렇?명븳 ?ъ슜???뺣낫($_SESSION['userid'] ??瑜??ъ슜?섍린 ?꾪빐 ?꾩슂??
    session_start(); 

    // DB ?곌껐 ?뚯씪??遺덈윭??
    include "dbconn.php";

    // 二쇱냼李?GET)?쇰줈 ?섏뼱???섏젙??湲 踰덊샇瑜?諛쏆쓬
    // ?? modify_form.php?num=5 ?대㈃ $num?먮뒗 5媛 ?ㅼ뼱媛?
    $num=$_GET['num'];

/** @var mysqli $connect */

    // boardlist ?뚯씠釉붿뿉??湲 踰덊샇媛 $num??寃뚯떆湲 ?섎굹瑜?媛?몄삤??SQL臾?
    $sql = "select * from boardlist where num=$num";

    // SQL臾??ㅽ뻾
    $result = mysqli_query( $connect,$sql);

    // ?ㅽ뻾 寃곌낵?먯꽌 寃뚯떆湲 ??以꾩쓣 諛곗뿴濡?媛?몄샂
    $row = mysqli_fetch_array($result);          

    // 媛?몄삩 寃뚯떆湲??제목??蹂?섏뿉 ???
    $item_subject     = $row['subject'];

    // 媛?몄삩 寃뚯떆湲??내용??蹂?섏뿉 ???
    $item_content     = $row['content'];
?>
<html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
    <link rel="stylesheet" href="css/exam.css?v=20260605-simple4">
<link  rel="stylesheet" href="css/common.css?v=20260605-simple4">
<link  rel="stylesheet" href="css/greet.css?v=20260605-simple4">

</head>

<body>

<div id="wrap">
  

  <div id="content">
    

    <div id="col2">        
        <div id="title">
            <img src="image/title_greet.gif">
        </div>

        <div class="clear"></div>

        <div id="write_form_title">
            <img src="image/write_form_title.gif">
        </div>
<? 
// ?섏젙 ?꾨즺 ??紐⑸줉?쇰줈 ?뚯븘媛????ъ슜???섏씠吏 踰덊샇瑜?1濡??ㅼ젙
$page = 1; 
?>
        <div class="clear"></div>

        <!-- 
            ?섏젙 ??
            mode=modify: insert1.php?먯꽌 ??湲 ?묒꽦???꾨땲???섏젙 泥섎━?꾩쓣 援щ텇?섍린 ?꾪븳 媛?
            num=$num: ?대뼡 湲???섏젙?좎? ?뚮젮二쇰뒗 湲 踰덊샇
            page=$page: ?섏젙 ???뚯븘媛??섏씠吏 踰덊샇
        -->
        <form  name="board_form" method="post" action="insert1.php?mode=modify&num=<?=$num?>&page=<?=$page?>"> 
        <div id="write_form">
            <div class="write_line"></div>
            <div id="write_row1">
                <div class="col1"> 닉네임</div>
                <div class="col2">
                    <!-- ?꾩옱 濡쒓렇?명븳 ?ъ슜?먯쓽 ?꾩씠?붾? ?붾㈃??異쒕젰 -->
                    <?=$_SESSION['userid']?>
                </div>
            </div>
            <div class="write_line"></div>
            <div id="write_row2"><div class="col1"> 제목   </div>
             <div class="col2">
                <!-- 湲곗〈 寃뚯떆湲 제목??input value???ｌ뼱???섏젙?????덇쾶 蹂댁뿬以?-->
                <input type="text" name="subject" value="<?=$item_subject?>" >
             </div>
            </div>
            <div class="write_line"></div>
            <div id="write_row3"><div class="col1"> 내용   </div>
            <div class="col2"><textarea rows="15" cols="79" name="content">
                <?=$item_content?></textarea></div>
            </div>
            <div class="write_line"></div>
        </div>

        <div id="write_button">
        <!-- ?대?吏 踰꾪듉???꾨Ⅴ硫?form??submit?섏뼱 insert1.php濡??섏젙 내용???꾩넚??-->
        <button type="submit" class="btn-submit-post">완료</button>&nbsp;

        <!-- 紐⑸줉 踰꾪듉???꾨Ⅴ硫??꾩옱 page 媛믪쑝濡?list.php 紐⑸줉?쇰줈 ?대룞 -->
        <a href="list.php?page=<?=$page?>"><img src="image/list.png"></a>
        </div>  
        </form>

    </div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->

</body>
</html>

<!-- 
1. ?몄뀡 ?쒖옉
2. DB ?곌껐
3. GET?쇰줈 ?섏젙??湲 踰덊샇 num 諛쏄린
4. num???대떦?섎뒗 寃뚯떆湲 議고쉶
5. 제목怨?내용??蹂?섏뿉 ???
6. ?섏젙 ??input/textarea??湲곗〈 제목怨?내용??誘몃━ ?ｌ쓬
7. ?뺤씤 踰꾪듉 ?대┃
8. insert1.php?mode=modify濡??섏젙 내용 ?꾩넚
 -->








