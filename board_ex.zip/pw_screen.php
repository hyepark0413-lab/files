﻿<? 
    session_start(); 
?>
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>비밀번호 찾기</title>
<link rel="stylesheet" href="css/reset.css?v=20260605-simple4">
<link rel="stylesheet" href="css/base.css?v=20260605-simple4">
</head>
<body>
<div id="join_mem">
<h2>비밀번호 찾기</h2>
<form name="member_form" method="post" action="pw_search.php">
<div id="join2">
<ul>
    <li>
        <label for="pid" class="b1">아이디</label>
        <input type="text" name="id" id="pid">
    </li>
    <li>
        <label for="a2" class="b2">전화번호</label>
        <input type="tel" class="hp" name="hp" id="a2">
    </li>
</ul>
</div>
<div id="write_button">
    <button type="submit" class="btn-submit-post">확인</button>
</div>
</form>
</div>
</body>
</html>

